create definer = root@localhost view cid3 as
select `leyou`.`tb_category`.`parent_id` AS `parent_id`
from `leyou`.`tb_category`
group by `leyou`.`tb_category`.`parent_id`;

